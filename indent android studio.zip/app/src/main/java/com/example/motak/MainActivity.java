package com.example.motak;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button kucing, anjing, Walang;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        kucing = (Button) findViewById(R.id.kucing);
        kucing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openKucing();
            }
        });

        anjing = (Button) findViewById(R.id.anjing);
        anjing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAnjing();
            }
        });

        Walang = (Button) findViewById(R.id.trap);
        Walang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openwalang();
            }
        });

    }

    public void openAnjing(){
        Intent intent = new Intent(this, Anjing.class);
        startActivity(intent);
    }

    public void openKucing(){
        Intent intent = new Intent(this, Kucing.class);
        startActivity(intent);
    }

    public void openwalang(){
        Intent intent = new Intent(this, walang.class);
        startActivity(intent);
    }

}